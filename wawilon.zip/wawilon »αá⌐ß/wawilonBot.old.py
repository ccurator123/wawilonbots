from telebot.async_telebot import AsyncTeleBot
from asyncio import run as _runner
from telebot.types import (
    Message,
    CallbackQuery,
    InlineKeyboardButton as IKB,
    InlineKeyboardMarkup as IKM,
    ReplyKeyboardMarkup as RKM,
    KeyboardButton as KB
)

bot = AsyncTeleBot(
    "7126712982:AAEg9jHnmuOaZx6rhYZktP1wyGItRmX6o0w"
)

manualsKB = IKM(
    keyboard=[
        [
            IKB(text='OSINT', callback_data='osintManuals'),
        ],
        [
            IKB(text='ANONYMITY', callback_data='anonymityManuals'),
        ],
        [
            IKB(text='SNOS', callback_data='snosManuals')
        ]
    ]
)
servicesKB = IKM(
    keyboard=[
        [], [], [], [], []
    ]
)

@bot.message_handler(commands=['start'])
async def start(message: Message) -> Message:
    return await bot.reply_to(
        message,
        f"Здравствуйте, {message.from_user.full_name}, "
        " добро пожаловать в прайс-лист.",
        reply_markup=RKM(resize_keyboard=True, row_width=2).add(
            KB("Мануалы"), KB("Сервис"), KB("Связь")
        )
    )

@bot.message_handler(regexp="Мануалы")
async def manualsList(message: Message) -> Message:
    return await bot.send_message(
        message.from_user.id,
        'OSINT\n'
        '<pre>'
        '5 level - 1500$\n\n'
        '4 level - 1000$\n\n'
        '3 level - 500$\n\n'
        '2 level - 250$\n\n'
        '1 level - 100$'
        '</pre>',
        parse_mode='HTML',
        reply_markup=manualsKB
    )


@bot.message_handler(regexp="Сервис")
async def services(message: Message) -> Message:
    return await bot.reply_to(
        message,
        '<pre>\n'
        'Поиск личности (OSINT) - цена договорная\n\n'
        'Def (защита) - от 100$\n\n'
        'Личное обучение -  от 300$ (в зависимости от того чему учить)\n\n'
        'Снос на заказ - цена договорная\n\n'
        'Реклама - от 35$\n\n'
        'Преф в чате - 30$\n'
        '</pre>',
        parse_mode='HTML'
    )


@bot.message_handler(regexp="Связь")
async def contactMe(message: Message) -> Message:
    return await bot.reply_to(
        message,
        'Связь со мной - @notwawilon\n'
        '<b>Сверяйте тег, не ведитесь на фейков!</b>',
        parse_mode='HTML'
    )


@bot.callback_query_handler(lambda call: call.data == 'osintManuals')
async def osintManuals(call: CallbackQuery) -> Message | bool:
    return await bot.edit_message_text(
        '<b>OSINT MANUALS\n'
        'Хотите получить руководство, которое сделает из вас настоящего '
        'шерлока в мире данных?</b>\n\n'
        'Наш мануал по OSINT — это ваш личный компас '
        'в океане открытой информации, где даже самые простые поисковые '
        'запросы могут привести вас к неожиданным открытиям!\n\n'
        'В этом мануале вы найдёте всё: от секретов поиска в социальных '
        'сетях до хитростей анализа публичных данных. Это не просто '
        'справочник — это ваша шпаргалка, чтобы не заблудиться '
        'в мире просторов интернета!\n\n'
        'С нашим мануалом вы сможете искать информацию так эффективно, '
        'что ваши друзья начнут подозревать, что вы читаете мысли. '
        'Получите истинные знания и станьте королём поиска с лёгкой иронией '
        'на языке и серьёзным подходом к делу!\n\n'
        'Price\n\n<pre>'
        '5 level - 1500$\n\n'
        '4 level - 1000$\n\n'
        '3 level - 500$\n\n'
        '2 level - 250$\n\n'
        '1 level - 100$'
        '</pre>',
        parse_mode='HTML',
        chat_id=call.from_user.id,
        message_id=call.message.id,
        reply_markup=manualsKB
    )


@bot.callback_query_handler(lambda call: call.data == 'anonymityManuals')
async def anonymityManuals(call: CallbackQuery) -> Message | bool:
    return await bot.edit_message_text(
        'ANONYMITY\n'
        '<pre>'
        '4 level - 1000$\n\n'
        '3 level - 500$\n\n'
        '2 level - 250$\n\n'
        '1 level - 100$'
        '</pre>',
        parse_mode='HTML',
        chat_id=call.from_user.id,
        message_id=call.message.id,
        reply_markup=manualsKB
    )


@bot.callback_query_handler(lambda call: call.data == 'snosManuals')
async def snosManuals(call: CallbackQuery) -> Message | bool:
    return await bot.edit_message_text(
        '<b>SNOS MANUAL</b>\n\n'
        'Пока другие хранят старые аккаунты и каналы, у вас есть шанс начать '
        'с чистого листа! Наш мануал по сносу Telegram-аккаунтов и каналов — '
        'это ваш ключ к свободе от цифрового хлама.\n\n'
        'С подробными пошаговыми инструкциями и полезными советами вы '
        'легко узнаете, как избавиться от ненужных "друзей" и каналов, '
        'которые пора списать в архив! С легкой иронией подходим к делу, '
        'потому что, согласитесь, иногда проще удалить лишнее, '
        'чем долго объяснять, почему вы больше не хотите '
        'следить за чьем-то котом.\n\n'
        'Очистите свое Telegram-пространство и дайте место тому, '
        'что действительно имеет значение!\n\n'
        'Price\n\n<pre>'
        '4 level - 500$\n\n'
        '3 level - 350$\n\n'
        '2 level - 150$\n\n'
        '1 level - 80$'
        '</pre>',
        parse_mode='HTML',
        chat_id=call.from_user.id,
        message_id=call.message.id,
        reply_markup=manualsKB
    )


while True:
    try:
        _runner(
            bot.polling(non_stop=True)
        )
    except BaseException:
        pass
