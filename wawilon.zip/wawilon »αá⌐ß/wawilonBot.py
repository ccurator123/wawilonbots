from telebot.async_telebot import AsyncTeleBot
from telebot.types import (
    Message,
    CallbackQuery,
    InlineKeyboardButton as IKB,
    InlineKeyboardMarkup as IKM,
    KeyboardButton as KB,
    ReplyKeyboardMarkup as RKM
)

from asyncio import run as _runner
from dotenv import load_dotenv
from os import getenv as _env


load_dotenv()
bot = AsyncTeleBot(_env('BOT_TOKEN'))

manualsKB = IKM(
    keyboard=[
        [
            IKB(text='OSINT', callback_data='osintManuals')
        ],
        # [
        #     IKB(text='ANONYMITY', callback_data='anonymityManuals'),
        # ],
        [
            IKB(text='SNOS', callback_data='snosManuals')
        ],
        [
            IKB(text='Прочее', callback_data='otherProducts')
        ]
    ]
)
servicesKB = IKM(
    keyboard=[
        [IKB(text='SNOS', callback_data='snosService')],
        [IKB(text='Обучение OSINT', callback_data='osintService')],
        [IKB(text='Поиск информации о личности', callback_data='doxService')],
        [
            IKB(
                text='Проверка анонимности',
                callback_data='anonymityCheckService'
            )
        ],
        [IKB(text='DEF (защита)', callback_data='defService')],
    ]
)


# -- Services Handlers -- #
@bot.callback_query_handler(lambda call: call.data == 'defService')
async def defService(event: CallbackQuery) -> Message | bool:
    return await bot.edit_message_text(
        '<b>DEF (защита)</b>\n\n'
        'Хотите чувствовать себя в интернете так же защищённо, '
        'как в коконе из мягких пледов?\n\n'
        '<b>Наша услуга личной защиты в интернете и настройки анонимности '
        'сделает вас невидимкой в мире цифровых наблюдателей!\n\n'
        'Мы поможем вам установить такие уровни безопасности, '
        'что ваши данные будут защищены лучше, чем сокровища в банке. '
        'Возьмём на себя все заботы о настройке анонимности, чтобы '
        'вы могли спокойно сёрфить по вебу, как будто у вас есть '
        'суперсила невидимости.\n\n'
        'С нами ваши секрете останутся при вас, а шпионские взгляды '
        'будут ловить лишь тень. Защитите свою цифровую жизнь с лёгким '
        'флёром иронии — ведь каждый герой нуждается в надежном помощнике!\n\n'
        '<i>Цена договорная</i></b>',
        event.from_user.id,
        event.message.id,
        event.inline_message_id,
        parse_mode='HTML',
        reply_markup=servicesKB
    )


@bot.callback_query_handler(lambda call: call.data == 'snosService')
async def snosService(event: CallbackQuery) -> Message | None:
    return await bot.edit_message_text(
        '<b>Услуга - SNOS НА ЗАКАZ</b>\n'
        ' Вы думаете, что некоторые ваши Telegram-аккаунты и каналы — '
        'это просто непрошенные соседи, которые заселились в '
        'вашем цифровом пространстве?\n\n'
        '<b>Мы предлагаем услугу по сносу аккаунтов и каналов в Telegram, '
        'чтобы вы могли избавиться от лишнего бремени и вернуть '
        'свой мессенджер к нормальной жизни!\n\n'
        'С нами процесс сноса будет не только эффективным, но и забавным: '
        'мы устраним ненужные профили с такой легкостью, будто удаляем '
        'случайно сделанное фото с отпуска. Забудьте о скучных процедурах — '
        'наши специалисты знают секреты, чтобы ваши нежелательные аккаунты '
        'исчезли без следа.\n\n'
        'Позвольте нам навести порядок в вашем Telegram! И помните: иногда '
        'лучше оставить старое в прошлом, чем позволять ему раздражать ваше '
        'первое утреннее сообщение!\n\n'
        '<i>Цена договорная от 100$</i></b>',
        event.from_user.id,
        event.message.id,
        event.inline_message_id,
        parse_mode='HTML',
        reply_markup=servicesKB
    )


@bot.callback_query_handler(lambda call: call.data == 'osintService')
async def osintService(event: CallbackQuery) -> Message | bool:
    return await bot.edit_message_text(
        '<b>Личное обучение Osint и мноим его направлениям\n\n</b>'
        'Хотите узнать, как стать виртуальным детективом без шляпы и '
        'увеличительного стекла? <b>Наш курс обучения OSINT даст вам '
        'инструменты для поиска информации из открытых источников так, '
        'что ваш сосед подумает, что вы подписаны на '
        'секретное правительственное агентство!\n\n'
        'Вы научитесь находить данные в соцсетях, форумах и не только, '
        'как настоящий профессионал — без навязчивых вопросов и неприятных '
        'ситуаций. Повысьте свои навыки анализа и верификации, чтобы все '
        'ваши друзья могли говорить: "Он знает о нас больше, чем мы сами!"\n\n'
        'Запишитесь на курс, и в итоге, возможно, вы станете не только '
        'экспертом в OSINT, но и получите незаменимую способность раскрывать '
        'тайны, спрятанные среди интернет-шума!\n\n'
        '<i>от 500$ и до 3500$</i></b>',
        event.from_user.id,
        event.message.id,
        event.inline_message_id,
        parse_mode='HTML',
        reply_markup=servicesKB
    )


@bot.callback_query_handler(lambda call: call.data == 'doxService')
async def doxService(event: CallbackQuery) -> Message | bool:
    return await bot.edit_message_text(
        '<b>Поиск информации о личности</b>\n\n'
        'Ищете правду о ком-то, кто обещал стать вашим "лучшим другом", '
        'но иногда вам кажется, что у него два родных брата — '
        'таинственность и лукавство? <b>Наша услуга поиска информации о '
        'личности предоставит вам не только интересные факты, но и надежные '
        'доказательства их правдивости, чтобы вы не оказались в роли '
        'главного героя детективного романа!\n\n'
        'Мы тщательно изучим доступные источники, соберем подтверждения и '
        'представим вам картину, о которой можно смело говорить '
        'на вечеринке, не опасаясь слов «просто слух».\n\n'
        'В конце концов, знать правду — это не только полезно, но и '
        'весьма увлекательно! С нами вы сможете разгадать личные тайны с '
        'легким налетом иронии и без лишних вопросов!\n\n'
        '<i>- цена зависит от жертвы.\n'
        '- От 80$</i></b>',
        event.from_user.id,
        event.message.id,
        event.inline_message_id,
        parse_mode='HTML',
        reply_markup=servicesKB
    )


@bot.callback_query_handler(lambda call: call.data == 'anonymityCheckService')
async def anonymityCheckService(event: CallbackQuery) -> Message | bool:
    return await bot.edit_message_text(
        '<b>Проверка анонимности, очистка следов.</b>\n\n'
        '<u>Хотите стать настолько неуловимым, что даже самый опытный детектив '
        'почесывает затылок в недоумении?</u>\n\n'
        '<b>Мы предлагаем услугу проверки анонимности, чтобы вы могли узнать, '
        'где оставили свои цифровые следы и как их скрыть.\n\n'
        'Если ваша информация уже разлетелась по сети, не переживайте!\n\n'
        'Мы проведем чистку данных так тщательно, что даже ваша '
        'тень будет задумываться, где бы ей укрыться.\n\n'
        'С нами вы сможете стать настоящим мастером анонимности — '
        'настоящим призраком в мире цифр!\n\n'
        '<i>- цена договорная</i></b>',
        event.from_user.id,
        event.message.id,
        event.inline_message_id,
        parse_mode='HTML',
        reply_markup=servicesKB
    )


# -- Manuals handlers -- #
@bot.callback_query_handler(lambda call: call.data == 'osintManuals')
async def osintManuals(event: CallbackQuery) -> Message | bool:
    return await bot.edit_message_text(
        '<b>OSINT MANUALS\n\n'
        'Хотите получить руководство, которое сделает из вас настоящего '
        'шерлока в мире данных?</b>\n\n'
        'Наш мануал по OSINT — это ваш личный компас в океане '
        'открытой информации, где даже самые простые поисковые запросы '
        'могут привести вас к неожиданным открытиям!\n\n'
        'В этом мануале вы найдете все: от секретов поиска в '
        'социальных сетях до хитростей анализа публичных данных. '
        'Это не просто справочник — это ваша шпаргалка, чтобы '
        'не заблудиться в мире просторов интернета!\n\n'
        'С нашим мануалом вы сможете искать информацию так эффективно, '
        'что ваши друзья начнут подозревать, что вы читаете мысли. '
        'Получите истинные знания и станьте королем поиска с легкой иронией '
        'на языке и серьезным подходом к делу!\n\n'
        'Price\n<pre>'
        '4 level - 990$\n\n'
        '3 level - 490$\n\n'
        '2 level - 240$\n\n'
        '1 level - 100$</pre>',
        event.from_user.id,
        event.message.id,
        event.inline_message_id,
        parse_mode='HTML',
        reply_markup=manualsKB
    )


@bot.callback_query_handler(lambda call: call.data == 'snosManuals')
async def snosManuals(event: CallbackQuery) -> Message | bool:
    return await bot.edit_message_text(
        '<b>SNOS MANUAL</b>\n\n'
        'Пока другие хранят старые аккаунты и каналы, у вас есть шанс начать '
        'с чистого листа! Наш мануал по сносу Telegram-аккаунтов и каналов — '
        'это ваш ключ к свободе от цифрового хлама.\n\n'
        'С подробными пошаговыми инструкциями и полезными советами вы '
        'легко узнаете, как избавиться от ненужных "друзей" и каналов, '
        'которые пора списать в архив! С легкой иронией подходим к делу, '
        'потому что, согласитесь, иногда проще удалить лишнее, чем долго '
        'объяснять, почему вы больше не хотите следить за чьем-то котом.\n\n'
        'Очистите свое Telegram-пространство и дайте место тому, что '
        'действительно имеет значение!\n\n'
        'Price\n<pre>'
        '4 level - 500$\n\n'
        '3 level - 350$\n\n'
        '2 level - 150$\n\n'
        '1 level - 80$</pre>',
        event.from_user.id,
        event.message.id,
        event.inline_message_id,
        parse_mode='HTML',
        reply_markup=manualsKB
    )


@bot.callback_query_handler(lambda call: call.data == 'otherProducts')
async def otherProducts(event: CallbackQuery) -> Message | bool:
    return await bot.edit_message_text(
        '<b>Канал</b>\n\n'
        'Реклама в канале\n'
        'price - от 35$\n\n'
        'Префикс в чате канала\n'
        'price - 40$\n\n'
        '<a href="https://t.me/+OZM0fxkCmLQ2YzQ8">Channel</a>\n'
        '<a href="https://t.me/+JC2GU_45F4o4N2Vk">Chat</a>',
        event.from_user.id,
        event.message.id,
        event.inline_message_id,
        parse_mode='HTML',
        disable_web_page_preview=True,
        reply_markup=manualsKB
    )


@bot.message_handler(commands=['start'])
async def start(message: Message) -> Message:
    return await bot.reply_to(
        message,
        f"Здравствуйте, добро пожаловать в прайс-лист.",
        reply_markup=RKM(resize_keyboard=True, row_width=2).add(
            KB("Товары"), KB("Сервис"), KB("Связь")
        )
    )


@bot.message_handler(regexp="Связь")
async def contactMe(message: Message) -> Message:
    return await bot.reply_to(
        message,
        'Связь со мной - @notwawilon\n'
        '<b>Сверяйте тег, не ведитесь на фейков!</b>',
        parse_mode='HTML'
    )


@bot.message_handler(func=lambda call: call.text == 'Товары')
async def products(message: Message) -> Message:
    return await bot.reply_to(
        message,
        'Выберите желаемый товар по кнопкам ниже.',
        reply_markup=manualsKB
    )

@bot.message_handler(func=lambda call: call.text == 'Мануалы')
async def manuals(message: Message) -> Message:
    return await products(message)


@bot.message_handler(func=lambda call: call.text == 'Сервис')
async def products(message: Message) -> Message:
    return await bot.reply_to(
        message,
        'Выберите желаемый товар по кнопкам ниже.',
        reply_markup=servicesKB
    )


while True:
    try:
        _runner(
            bot.polling(non_stop=True)
        )
    except BaseException:
        pass
