from aiosqlite import connect
from extensions import (
    info, warn, error,
    DATABASE, SESSION, API_ID,
    API_HASH, APP, SYSTEM
)

from asyncio import run as _runner
from os.path import exists
from traceback import format_exc

from telethon import TelegramClient


async def main() -> None:
    session: TelegramClient
    try:
        async with connect(DATABASE) as _DB:
            info('Creating table "defs"...')
            await _DB.execute(
                'CREATE TABLE IF NOT EXISTS defs ('
                'username TEXT, '
                'tg_id INTEGER NOT NULL'
                ')'
            )
            info('Done.')
            info('Creating table "delay"...')
            await _DB.execute(
                'CREATE TABLE IF NOT EXISTS delay ('
                'tg_id INTEGER NOT NULL, '
                'timestamp INTEGER NOT NULL'
                ')'
            )
            info('Done.')
            info('Commiting changes...')
            await _DB.commit()
    except BaseException as errorText:
        error(
            'Unexpected error while '
            f'creating/commiting changes to database: {errorText}'
        )
        info(f'Full TraceBack:\n{format_exc()}')
        return error('Changes not applied. Exiting...')

    try:
        if exists(SESSION):
            info('Validating session file...')
            async with TelegramClient(
                SESSION, API_ID, API_HASH,
                app_version=APP, system_version=SYSTEM
            ) as session:
                if await session.is_user_authorized():
                    data = await session.get_me()
                    info(
                        f'Successfully logged as {data.id} '
                        f'({data.username})' if data.username else ''
                    )
                    return info('Working done. Exiting...')
        info('Creating session file...')
        warn('Follow the Telethon module instructions.')
        async with TelegramClient(
            SESSION, API_ID, API_HASH, app_version=APP, system_version=SYSTEM
        ) as session:
            data = await session.get_me()
            info(
                f'Successfully logged as {data.id} '
                f'({data.username})' if data.username else ''
            )
        return info('Working done. Exiting...')
    except BaseException as err:
        error(f'Error while logging to telegram: {err}')
        info(f'Full TraceBack:\n{format_exc()}')
        return error('Exiting...')

if exists(DATABASE):
    warn('Database file already exists.')
if exists(SESSION):
    warn('Telethon session file already exists.')
_runner(main())
