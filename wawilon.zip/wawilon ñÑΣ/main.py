from telebot.async_telebot import AsyncTeleBot
from telebot.types import Message

from database import database, updater
from extensions import (
    BOT_TOKEN, ADMINS, getUser,
    error, info, checkLetters
)

from traceback import format_exc
from asyncio import (
    gather as _event_loop,
    run as _runner
)

bot = AsyncTeleBot(BOT_TOKEN)
db = database()


@bot.message_handler(commands=['start'])
async def start(message: Message) -> Message:
    if message.from_user.id in ADMINS:
        return await bot.send_message(
            message.from_user.id,
            'Здравствуйте, Евгений. Через данного бота мы можете '
            'собрать список своих подзащитных ("дефов"), для проверки '
            'пользователями личностей на наличие вашего "дефа".\n\n'
            'ℹ️ Для добавления пользователя в список используйте > '
            '/add [@username | ID пользователя]\n'
            'ℹ️ Для удаления пользователя из списка используйте > '
            '/remove [@username | ID пользователя]\n'
            'ℹ️ Чтобы посмотреть список всех дефов, пропишите > /list\n'
            '    ⚠️ <i>Данная команда доступна только вам.</i>',
            parse_mode='HTML'
        )
    return await bot.send_message(
        message.from_user.id,
        '👋 Здравствуйте! С помощью данного бота вы можете узнать, '
        'пользуется ли человек услугами дефа от Евгения Вавилонова.\n'
        'ℹ️ Для получения информации о том, состоит ли человек в дефах у '
        'Евгения, отправьте его @username или ID.'
    )


@bot.message_handler(
    commands=['add'], func=lambda message: message.from_user.id in ADMINS
)
async def addDef(message: Message) -> Message:
    payload = message.text.split(' ')[-1]
    if payload.lower().startswith('/add'):
        return await bot.reply_to(
            message,
            'ℹ️ Используйте > /add [@username или ID пользователя]'
        )

    if payload.isdigit():
        payload = await getUser('ID', int(payload))
    else:
        payload = await getUser('USERNAME', payload.split('@')[-1])

    if await db.getDef('ID', payload['tg_id']):
        return await bot.reply_to(
            message,
            '⭕️ Данный пользователь уже есть в базе!\n'
            'ℹ️ Посмотреть список дефов можно командой > /list'
        )

    await db.addDef(
        payload['username'] if payload['username'] else '', payload['tg_id']
    )
    return await bot.reply_to(
        message,
        f'✅ Пользователь {payload["full_name"]} добавлен в список дефов!'
    )


@bot.message_handler(
    commands=['remove'], func=lambda message: message.from_user.id in ADMINS
)
async def removeDef(message: Message) -> Message:
    payload = message.text.split(' ')[-1]
    if payload.lower().startswith('remove'):
        return await bot.reply_to(
            message,
            'ℹ️ Используйте > /remove [@username или ID пользователя]'
        )

    if payload.isdigit():
        payload = await getUser('ID', int(payload))
    else:
        payload = await getUser('USERNAME', payload.split('@')[-1])

    if not await db.getDef(tg_id=payload['tg_id']):
        return await bot.reply_to(
            message, '⭕️ Такого пользователя нет в базе.'
        )

    await db.removeDef(tg_id=payload['tg_id'])
    return await bot.reply_to(
        message,
        f'✅ Пользователь {payload["full_name"]} удалён из списка дефов!'
    )


@bot.message_handler(
    commands=['list'], func=lambda message: message.from_user.id in ADMINS
)
async def defsList(message: Message) -> None:
    defs = await db.getAll()
    text = 'ℹ️ Список подзащитных:\n\n'
    for user in defs:
        username = f'@{user[0]}' if (
            user[0] and user[0] != 'None'
        ) else 'Отсуствтвует'
        text += (
            f'👤 Ник пользователя: {username}\n'
            f'🆔 ID пользователя: <code>{user[1]}</code>\n\n'
        )

    for _part in range(0, len(text), 4096):
        await bot.send_message(
            message.from_user.id, text[_part:_part+4096], parse_mode='HTML'
        )
    return


@bot.message_handler()
async def getDef(message: Message) -> Message | None:
    payload = message.text
    _TEMP = message.text.lower()
    if not await db.checkCooldown(message.from_user.id):
        return await bot.reply_to(
            message, '❌ Подождите 10 секунд перед отправкой нового запроса!'
        )
    await db.updateCooldown(message.from_user.id)

    if not await checkLetters(_TEMP.split('@')[-1]) and _TEMP.count('@') < 2:
        return await bot.reply_to(
            message, 'ℹ️ Использование > [@Username | ID]'
        )

    try:
        if payload.isdigit():
            payload = await db.getDef('ID', int(payload))
        else:
            _payload = await db.getDef('USERNAME', payload.split('@')[-1])
            if not _payload:
                _payload = await getUser('USERNAME', payload.split('@')[-1])
                payload = await db.getDef('ID', _payload['tg_id'])
            else:
                payload = True

        if payload:
            return await bot.reply_to(
                message,
                '✅ Данный пользователь '
                'числится в списке тех кто под дефом!'
            )
        return await bot.reply_to(
            message, '❌ Данный пользователь не числится в списке.'
        )

    except (ValueError, AttributeError) as err:
        error(f'_getUser(): Error: {err}\n{format_exc()}')
        return await bot.reply_to(
            message, "ℹ️ Такого пользователя не существует!"
        )
    except BaseException as err:
        error(f'_getUser(): Error: {err}\n{format_exc()}')
        return await bot.reply_to(
            message, '❌ Данный пользователь не числится в списке.'
        )


async def _() -> None:
    async def __() -> None: info('Bot started.')
    while True:
        try:
            info('Running tasks...')
            await _event_loop(
                bot.polling(), updater(), __()
            )
        except BaseException as err:
            error(f'Error while polling: {err}\n{format_exc()}')


if __name__ == '__main__':
    _runner(_())
