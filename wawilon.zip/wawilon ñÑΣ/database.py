from aiosqlite import connect
from extensions import (
    DATABASE, info, error, client, _By, warn
)

from os.path import exists
from functools import lru_cache
from asyncio import sleep as asleep
from traceback import format_exc
from time import time

from typing import Iterable
from sqlite3 import Row


class database:
    @lru_cache
    def __init__(self) -> None:
        if not exists(DATABASE):
            raise FileNotFoundError(
                'Database file not found. '
                'Perhaps you forget perform initial setup?'
            )

    async def getDef(self, by: _By, payload: int | str) -> bool:
        async with connect(DATABASE, timeout=20) as _DB:
            if by == 'ID':
                return True if (
                    len(
                        await _DB.execute_fetchall(
                            f'SELECT * FROM defs WHERE tg_id={payload}'
                        )
                    )
                ) else False
            return True if (
                len(
                    await _DB.execute_fetchall(
                        f'SELECT * FROM defs WHERE username="{payload}"'
                    )
                )
            ) else False

    async def checkCooldown(self, tg_id: int) -> bool:
        async with connect(DATABASE, timeout=20) as _DB:
            _TEMP = await _DB.execute_fetchall(
                f'SELECT timestamp FROM delay WHERE tg_id={tg_id}'
            )
            if not _TEMP or int(time()) - _TEMP[0][0] >= 10:
                return True
            return False

    async def updateCooldown(self, tg_id: int) -> None:
        async with connect(DATABASE, timeout=20) as _DB:
            _TEMP = await _DB.execute_fetchall(
                f'SELECT * FROM delay WHERE tg_id={tg_id}'
            )
            if _TEMP:
                await _DB.execute(
                    f'UPDATE delay SET timestamp={int(time())} '
                    f'WHERE tg_id={tg_id}'
                )
            else:
                await _DB.execute(
                    'INSERT INTO delay (tg_id, timestamp) VALUES ('
                    f'{tg_id}, {int(time())})'
                )
            return await _DB.commit()

    async def addDef(self, username: str, tg_id: int) -> None:
        async with connect(DATABASE, timeout=20) as _DB:
            await _DB.execute(
                f'INSERT INTO defs (username, tg_id) '
                f'VALUES ("{username}", {tg_id})'
            )
            return await _DB.commit()

    async def removeDef(self, tg_id: int) -> None:
        async with connect(DATABASE, timeout=20) as _DB:
            await _DB.execute(
                f'DELETE FROM defs WHERE tg_id={tg_id}'
            )
            return await _DB.commit()

    async def getAll(self) -> Iterable[Row]:
        async with connect(DATABASE, timeout=20) as _DB:
            return await _DB.execute_fetchall('SELECT * FROM defs')


async def updater() -> None:
    while True:
        await client.connect()
        affected = 0

        info('Performing database update...')
        async with connect(DATABASE, timeout=20) as _DB:
            ids = await _DB.execute_fetchall('SELECT * FROM defs')
            info(f'Database length > {len(ids)} rows.')
            await _DB.close()

        async with client:
            async with connect(DATABASE, timeout=20) as _DB:
                for user in ids:

                    username = user[0]
                    tg_id = user[1]

                    try:
                        data = await client.get_entity(tg_id)
                    except BaseException as err:
                        error(
                            'Error in .get_entity process: '
                            f'{err}\n{format_exc()}'
                        )
                        if username == 'None':
                            info('User not have a username.')
                            warn('Transaction skipped.')
                            continue
                        info('Trying to get user via username...')
                        try:
                            data = await client.get_entity(username)
                        except BaseException:
                            warn(f"Can't get user {username} ({tg_id})")
                            warn('Transaction skipped.')
                    _DB_data = await _DB.execute_fetchall(
                        f'SELECT username FROM defs WHERE tg_id={data.id}'
                    )

                    if data.username != _DB_data[0][0]:
                        await _DB.execute(
                            f'UPDATE defs SET username="{data.username}" '
                            f'WHERE tg_id={tg_id}'
                        )
                        affected += 1
                    await asleep(1)

                await _DB.commit()
                info(f'Update success, {affected} rows affected.')
                await _DB.close()
        await asleep(1800)
