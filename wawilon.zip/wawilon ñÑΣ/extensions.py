# Extensions for project.
from rich.console import Console
from datetime import datetime

from dotenv import load_dotenv
from json import loads
from os import getenv

from typing import TypeAlias, Literal

from telethon import TelegramClient


_By: TypeAlias = Literal['ID', 'USERNAME']
_AcceptedLetters = [
    'a', 'b', 'c', 'd', 'e', 'f',
    'g', 'h', 'i', 'j', 'k', 'l',
    'm', 'n', 'o', 'p', 'q', 'r',
    's', 't', 'u', 'v', 'w', 'x',
    'y', 'z', '@', '1', '2', '3',
    '4', '5', '6', '7', '8', '9',
    '0', '_'
]
_StopWords = open('./npermitted.txt').read().split('\n')


load_dotenv()
console = Console()
_error = Console(stderr=True)
DATABASE = './db.sqlite3'
API_ID = int(getenv("API_ID"))
API_HASH = getenv("API_HASH")
BOT_TOKEN = getenv("BOT_TOKEN")
ADMINS = loads(getenv("ADMIN_ID"))
SESSION = getenv("SESSION_PATH")
APP = 'wawilonDefs Database Updater'
SYSTEM = 'Debian 6.1.99-1 (2024-07-15) x86_64'


# Markdown print
def print(text: str) -> None: return console.print(text)
def _ePrint(text: str) -> None: return _error.print(text)


# Get time in format like "d:m:yyyy h:mm:ss.ms"
def get_time() -> str:
    time = datetime.now()

    minute, second = str(time.minute), str(time.second)
    minute = f'0{minute}' if len(minute) == 1 else minute
    second = f'0{second}' if len(second) == 1 else second

    return (
        f'{time.day}:{time.month}:{time.year} '
        f'{time.hour}:{minute}:{second}.{time.microsecond}'
    )


def warn(text: str) -> None:
    return print(
        f'[bold yellow][*][/bold yellow] '
        f'[{get_time()}] [yellow]{text}[/yellow]'
    )


def error(text: str) -> None:
    return _ePrint(
        f'[red][x][/red] [{get_time()}] [red]{text}[/red]'
    )


def info(text: str) -> None:
    return print(
        f'[bold cyan][-][/bold cyan] [{get_time()}] [cyan]{text}[/cyan]'
    )


client = TelegramClient(
    SESSION, API_ID, API_HASH, app_version=APP, system_version=SYSTEM
)
info(f'Connected to Telegram via session "{SESSION}"')


async def getUser(by: _By, payload: str | int) -> dict[str, int | str] | None:
    if payload in _StopWords:
        return
    async with client:
        data = await client.get_entity(payload)
        full_name = (
            f'{data.first_name if data.first_name else ""} '
            f'{data.last_name if data.last_name else ""}'
        )
        return {
            'tg_id': data.id,
            'username': data.username,
            'full_name': full_name
        }


async def checkLetters(text: str) -> bool:
    if text in _StopWords:
        return False
    for letter in text:
        if letter not in _AcceptedLetters:
            return False
    return True
