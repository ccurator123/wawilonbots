## Wawilon Def Bot - Бот для составления списка подзащитных

### Установка и настройка
1. Создать virtualenv - `virtualenv env`
2. Установить пакеты из Pipfile - `pipenv install`
3. Запустить setup.py - `python3 setup.py`
4. Заполнить .env:
> [!note]
> Шаблон для заполнения
> ```.env
> BOT_TOKEN = 6777697907:AAE-oifoifgigjk6523dpeEhJHNDSLhfds
> ADMIN_ID = [1543, 346345]
> API_ID = 326534
> API_HASH = sfgsijgrhgeuwrhterfsdhjgb
> SESSION_PATH = ./session.session
> ```

## Запуск

### Ручной Запуск
> [!caution]
>
> Просим вас выполнять ручной запуск бота только в случае отладки. В ином случае выполняйте запуск с помощью supervisord.

После выполнения файла установки (setup.py) введите команду `python3 bot.py`

### Запуск через supervisor

#### 1. Создание конфигурационного файла
Шаблон:
```conf
[program:WawilonDefs]
autostart=true
autorestart=true
user=root
directory=/root/wawilonDefs
stdout_logfile=/root/wawilonDefs.log
stderr_logfile=/root/wawilonDefs.err.log
pidfile=/root/wawilonDefs.pid
command=/root/wawilonDefs/env/bin/python3 /root/wawilonDefs/main.py
```

> [!note]
>
> Все конфигурационные файлы должны храниться по пути `/etc/supervisor/conf.d/` и НИГДЕ более.

После создания конфигурационного файла вы должны добавить его в supervisorctl.
```bash
# Пример
supervisorctl add wawilonDefs
```
Теперь, его можно запустить:
```bash
supervisorctl start wawilonDefs
```

> [!tip]
> Для чего нужно работать через supervisor?
>
> **Дело в том, что никто вам не гарантирует, что сервер будет работать без перезапусков. Рано или поздно сервер будет выключен на техобслуживание. Во избежание случаев остановки бота до вмешательства человека и используется supervisor, который запустит бота сразу же после загрузки системы.**
