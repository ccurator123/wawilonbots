from asyncio import run as _runner
from aiosqlite import connect

DATABASE = './db.sqlite3'


async def main() -> None:
    async with connect(DATABASE) as _DB:
        await _DB.execute(
            'CREATE TABLE IF NOT EXISTS requests ('
            'username TEXT, '
            'tg_id INTEGER NOT NULL, '
            'full_name TEXT NOT NULL, '
            'question_id INTEGER NOT NULL, '
            'message_id INTEGER NOT NULL'
            ')'
        )

        await _DB.execute(
            'CREATE TABLE IF NOT EXISTS state ('
            'tg_id INTEGER NOT NULL, '
            'state INTEGER NOT NULL, '
            'id INTEGER'
            ')'
        )

        await _DB.execute(
            'CREATE TABLE IF NOT EXISTS banned ('
            'tg_id INTEGER NOT NULL'
            ')'
        )

        return await _DB.commit()

if __name__ == '__main__':
    _runner(main())
