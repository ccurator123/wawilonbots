from aiosqlite import connect
from os.path import exists
from typing import TypeAlias, Literal
from telebot.types import (
    InlineKeyboardButton as IKB,
    InlineKeyboardMarkup as IKM
)

DATABASE = './db.sqlite3'

_State: TypeAlias = Literal['idle', 'answering']
_UserStatus: TypeAlias = Literal['banned', 'unbanned']
states = {
    'idle': 0,
    'answering': 1
}

if not exists(DATABASE):
    raise FileNotFoundError('Database file not found.')


def linked_username(tg_id: int, full_name: str) -> str:
    return f'<a href="tg://user?id={tg_id}">{full_name}</a>'


async def getSize() -> int:
    async with connect(DATABASE) as _DB:
        return len(
            await _DB.execute_fetchall('SELECT * FROM requests')
        )


async def addQuestion(
    tg_id: int, full_name: str, message_id: int, username: str | None = None
) -> int:
    full_name = full_name.encode().hex()
    async with connect(DATABASE) as _DB:
        if username:
            _username = 'username,'
            username = f'"{username}",'
        else:
            username, _username = '', ''

        await _DB.execute(
            'INSERT INTO requests ('
            f'{_username} tg_id, full_name, question_id, message_id'
            ') VALUES ('
            f'{username}'
            f'{tg_id}, "{full_name}", {await getSize() + 1}, {message_id}'
            ')'
        )
        await _DB.commit()
        return await getSize()


async def setState(tg_id: int, state: _State, question_id) -> None:
    async with connect(DATABASE) as _DB:
        if not await _DB.execute_fetchall(
            f'SELECT state FROM state WHERE tg_id={tg_id}'
        ):
            await _DB.execute(
                'INSERT INTO state ('
                'tg_id, state, id'
                ') VALUES ('
                f'{tg_id}, {states[state]}, {question_id}'
                ')'
            )
        else:
            await _DB.execute(
                f'UPDATE state SET state={states[state]}, '
                f'id={question_id} WHERE tg_id={tg_id}'
            )
        return await _DB.commit()


async def getState(tg_id: int) -> tuple[bool, int | None]:
    async with connect(DATABASE) as _DB:
        _state = await _DB.execute_fetchall(
            f'SELECT state, id FROM state WHERE tg_id={tg_id}'
        )

        if not _state:
            return False, None

        _state[0] += (None,)
        return bool(_state[0][0]),  _state[0][1]


async def getUser(question_id: int) -> tuple[int, int]:
    async with connect(DATABASE) as _DB:
        return (
            await _DB.execute_fetchall(
                f'SELECT tg_id, message_id FROM requests '
                f'WHERE question_id={question_id}'
            )
        )[0]


async def isBanned(tg_id: int) -> bool:
    async with connect(DATABASE) as _DB:
        if len(
            await _DB.execute_fetchall(
                f'SELECT * FROM banned WHERE tg_id={tg_id}'
            )
        ):
            return True
        return False


async def banUser(tg_id: int) -> None:
    async with connect(DATABASE) as _DB:
        await _DB.execute(f'INSERT INTO banned VALUES ({tg_id})')
        return await _DB.commit()


async def unbanUser(tg_id: int) -> None:
    async with connect(DATABASE) as _DB:
        await _DB.execute(f'DELETE FROM banned WHERE tg_id={tg_id}')
        return await _DB.commit()


def generateKeyboard(status: _UserStatus, question_id: int, tg_id: int) -> IKM:
    reply_button = [
        IKB(text='💬 Ответить', callback_data=f'answer {question_id}')
    ]

    if status == 'banned':
        return IKM(
            keyboard=[
                reply_button, [
                    IKB(
                        text='🟢 Разблокировать',
                        callback_data=f'_unban {tg_id} {question_id}'
                    )
                ]
            ]
        )
    return IKM(
        keyboard=[
            reply_button,
            [
                IKB(
                    text='⭕️ Заблокировать',
                    callback_data=f'_ban {tg_id} {question_id}'
                )
            ]
        ]
    )
