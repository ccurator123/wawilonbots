from telebot.async_telebot import AsyncTeleBot
from telebot.util import content_type_media
from telebot.types import (
    Message,
    CallbackQuery,
    InlineKeyboardButton as IKB,
    InlineKeyboardMarkup as IKM
)

from asyncio import run as _runner, sleep as asleep
from os import getenv
from dotenv import load_dotenv
from json import loads

from funcs import (
    linked_username, getUser,
    getState, setState, addQuestion,
    generateKeyboard, banUser, unbanUser,
    isBanned
)


load_dotenv()
bot = AsyncTeleBot(getenv('BOT_TOKEN'))
wawilon_accs = loads(getenv('ADMINS'))


@bot.message_handler(commands=['start'])
async def start(message: Message) -> Message:
    tg_id = message.from_user.id
    full_name = message.from_user.full_name
    if message.from_user.id in wawilon_accs:
        return await bot.send_message(
            message.from_user.id,
            'Добро пожаловать, Евгений. '
            'Сюда вы будете получать сообщения от пользователей'
        )

    return await bot.reply_to(
        message,
        f'👋 Добро пожаловать! '
        'Через данного бота вы можете связаться с Евгением Вавилоновым '
        'лично и задать ему интересующий вас вопрос, на который он '
        'обязательно ответит!\n'
        'ℹ️ Для отправки, просто напишите интересующий вас вопрос.',
        parse_mode='HTML'
    )


@bot.message_handler(
    content_types=content_type_media,
    func=lambda message: message.from_user.id not in wawilon_accs
)
async def question(message: Message) -> Message | None:
    tg_id = message.from_user.id
    full_name = message.from_user.full_name

    if await isBanned(tg_id):
        return await bot.reply_to(
            message, '✅ Ваш вопрос был отправлен успешно! Ожидайте ответа.'
        )


    question_id = await addQuestion(
        tg_id, full_name, message.id, message.from_user.username
    )

    for wawilon in wawilon_accs:
        await bot.copy_message(wawilon, message.from_user.id, message.id)
        await asleep(0.1)
        await bot.send_message(
            wawilon,
            f'📥️ Новый вопрос от > {linked_username(tg_id, full_name)}\n'
            f'ℹ️ ID пользователя > {tg_id}\n'
            'Для ответа нажмите кнопку ниже.',
            parse_mode='HTML',
            reply_markup=generateKeyboard('unbanned', question_id, tg_id)
        )

    return await bot.reply_to(
        message, '✅ Ваш вопрос был отправлен успешно! Ожидайте ответа.'
    )


@bot.message_handler(
    content_types=content_type_media,
    func=lambda message: message.from_user.id in wawilon_accs
)
async def answer(message: Message) -> Message | None:
    state, question_id = await getState(message.from_user.id)
    if not state:
        return

    tg_id, message_id = await getUser(question_id)
    await setState(message.from_user.id, 'idle', 0)

    await bot.send_message(
        tg_id, '📥️ Вам поступил ответ от Евгения!',
        reply_to_message_id=message_id
    )
    await asleep(.1)
    await bot.copy_message(
        tg_id, message.from_user.id, message.id,
    )
    await asleep(.1)
    return await bot.reply_to(message, '✅ Отлично, ваш ответ отправлен.')


@bot.callback_query_handler(func=lambda call: 'answer' in call.data)
async def answerStaging(event: CallbackQuery) -> Message:
    question_id = int(event.data.split(' ')[1])
    await setState(event.from_user.id, 'answering', question_id)
    return await bot.reply_to(
        event.message,
        '✍️ Начинайте писать ответ.\n'
        '❌ Для отмены, нажмите кнопку ниже.',
        reply_markup=IKM(
            keyboard=[[IKB(text='❌ Отмена', callback_data='cancelAnswer')]]
        )
    )


@bot.callback_query_handler(func=lambda call: 'cancelAnswer' in call.data)
async def cancelAnswer(event: CallbackQuery) -> Message:
    await setState(event.from_user.id, 'idle', 0)
    await bot.delete_message(event.from_user.id, event.message.id)
    await asleep(0.1)
    return await bot.send_message(event.from_user.id, '❌ Действие отменено.')


@bot.callback_query_handler(func=lambda call: '_ban' in call.data)
async def ban_user(event: CallbackQuery) -> Message | bool:
    dataset: list[int] = event.data.split(' ')[1:]  # Rofls
    tg_id, question_id = dataset[0], dataset[1]
    await banUser(tg_id)
    await asleep(.1)
    return await bot.edit_message_text(
        f'{event.message.text}\n\n'
        '⭕️ <b>Пользователь заблокирован!</b>\n'
        'ℹ️ Пользователь никогда не узнает, что он заблокирован. '
        'Сообщения от пользователя не будут более переадресовываться вам.\n'
        'ℹ️ Вы всё ещё можете ответить пользователю по кнопке ниже.',
        event.from_user.id, event.message.id,
        parse_mode='HTML',
        reply_markup=generateKeyboard('banned', question_id, tg_id)
    )


@bot.callback_query_handler(func=lambda call: '_unban' in call.data)
async def unban_user(event: CallbackQuery) -> Message | bool:
    dataset: list[int] = event.data.split(' ')[1:]  # Rofls
    tg_id, question_id = dataset[0], dataset[1]
    await unbanUser(tg_id)
    await asleep(.1)
    return await bot.edit_message_text(
        event.message.text.split('\n\n')[0],
        event.from_user.id, event.message.id,
        parse_mode='HTML',
        reply_markup=generateKeyboard('unbanned', question_id, tg_id)
    )


while True:
    try:
        _runner(
            bot.polling()
        )
    except BaseException as e:
        print(e)
